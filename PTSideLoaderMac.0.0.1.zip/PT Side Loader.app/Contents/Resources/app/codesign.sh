

export IDENTITY="3rd Party Mac Developer Application: Mang Yang (3LCXQ4DEK6)"
export PARENT_PLIST=out/PT\ Side\ Loader-darwin-x64/PT\ Side\ Loader.app/Contents/PTLover.entitlements
export CHILD_PLIST=out/PT\ Side\ Loader-darwin-x64/PT\ Side\ Loader.app/Contents/Frameworks/PT\ Side\ Loader\ Helper.app/PTSideLoader.entitlements
export APP_PATH=out/PT\ Side\ Loader-darwin-x64/PT\ Side\ Loader.app

#codesign --deep -s $IDENTITY --entitlements $CHILD_PLIST $APP_PATH"/Contents/Frameworks/PT Side Loader Helper.app"

#codesign --deep -s $IDENTITY --entitlements $CHILD_PLIST $APP_PATH"/Contents/Frameworks/PT\ Side\ Loader\ Helper\ EH.app"

#codesign --deep -s $IDENTITY --entitlements $CHILD_PLIST $APP_PATH"/Contents/Frameworks/PT\ Side\ Loader\ Helper\ NP.app"

codesign --deep -s $IDENTITY --entitlements $PARENT_PLIST $APP_PATH
