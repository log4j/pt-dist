export IDENTITY="3rd Party Mac Developer Application: Mang Yang (3LCXQ4DEK6)"
export APP_DIR="./out/PT\ Side\ Loader-darwin-x64"
export APP_NAME="PT\ Side\ Loader"
cd $APP_DIR && productbuild --component "$APP_NAME.app" /Applications --sign $IDENTITY "$APP_NAME.pkg"